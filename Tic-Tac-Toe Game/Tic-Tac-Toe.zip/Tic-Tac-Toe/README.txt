ABOUT

This is my first desktop project built using C# and Windows Forms.
I made it as part of my learning journey to understand how desktop
applications work especially event handling, UI design, and logic control.
The game uses bitwise operations to check winners quickly and cleanly.
You can play either against a friend or the computer.

HOW TO PLAY

1. Run "Tic-Tac-Toe Game.exe"
2. Choose your opponent (Friend or Computer)
3. Click any box to place your mark (X or O)
4. First player to align 3 marks wins the round!

FEATURES

- Player vs Player and Player vs Computer modes
- Fast winner detection using bitwise logic
- Embedded resources (no extra files needed)
- Simple yellow & black arcade-style interface
- Fully portable (no installation required)


--------------------------------------------------
This project represents my first real step into
desktop programming built from scratch, coded
and designed by me (Abdullah Alzahrani).

Thank you for trying it out!
Visit my portfolio on Abdullahsz.com