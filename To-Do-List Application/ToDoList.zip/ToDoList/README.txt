#ToDoList App

A simple Windows Forms To-Do List app built with C#.
It lets you create, edit, and delete tasks across categories all data is saved automatically in a local JSON file.

#Data Storage
Your tasks are stored locally at:
C:\Users\<YourName>\AppData\Local\ToDoList\tasks_data.json

#Notes
- No installation required.
- All data stays on your computer.
- Built using .NET Framework and Newtonsoft.Json.

Visit me at Abdullahsz.com

